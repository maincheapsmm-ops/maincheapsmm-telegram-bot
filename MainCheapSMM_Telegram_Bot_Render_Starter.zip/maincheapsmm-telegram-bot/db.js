const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : false,
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users_mirror (
      user_id BIGINT PRIMARY KEY,
      username TEXT NOT NULL,
      balance NUMERIC(14,2) NOT NULL DEFAULT 0,
      telegram_chat_id BIGINT UNIQUE,
      telegram_username TEXT,
      linked_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS categories_mirror (
      category_id BIGINT PRIMARY KEY,
      name TEXT NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS services_mirror (
      service_id BIGINT PRIMARY KEY,
      category_id BIGINT,
      name TEXT NOT NULL,
      price NUMERIC(14,4) NOT NULL DEFAULT 0,
      min_qty INTEGER NOT NULL DEFAULT 1,
      max_qty INTEGER NOT NULL DEFAULT 1,
      delivery TEXT NOT NULL DEFAULT '',
      sort_order INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS orders_mirror (
      order_id TEXT PRIMARY KEY,
      user_id BIGINT NOT NULL,
      telegram_chat_id BIGINT,
      link TEXT NOT NULL DEFAULT '',
      quantity INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Pending',
      start_count INTEGER,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS link_otps (
      telegram_chat_id BIGINT PRIMARY KEY,
      username TEXT NOT NULL,
      otp_hash TEXT NOT NULL,
      expires_at TIMESTAMPTZ NOT NULL,
      referrer_user_id BIGINT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS link_attempts (
      telegram_chat_id BIGINT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      PRIMARY KEY (telegram_chat_id)
    );
    CREATE INDEX IF NOT EXISTS orders_mirror_user_created_idx
      ON orders_mirror(user_id, created_at DESC);
  `);
}

module.exports = { pool, initDb };
