# MainCheapSMM Telegram Bot — Render package

This package is a **first integration build** based on the PHP bridge contracts found in the supplied panel ZIP. It is not yet safe to treat as production-complete.

## Important before deploying

1. The panel ZIP's `functions.php` contains a hard-coded bridge secret and an example/legacy Render URL. Rotate the secret and update both the panel config and Render environment variable to the same new value. Never commit real tokens or secrets.
2. Set `TELEGRAM_BOT_TOKEN`, `PANEL_BASE_URL`, `BRIDGE_SHARED_SECRET`, `DATABASE_URL`, and optionally `PGSSL` in Render.
3. Create a Render PostgreSQL database and use its Internal Database URL where possible.
4. Upload the **contents** of this folder to the GitHub repository (not the website PHP ZIP), then create a Render Web Service connected to that repository.
5. Build command: `npm install`
6. Start command: `npm start`
7. Health check path: `/health`

## Current features in this build

- Telegram long polling and main menu.
- Catalog mirror sync endpoint matching the panel's `/bridge/sync-catalog` POST.
- User and balance mirror sync endpoints.
- Services/categories browsing.
- Order placement through the panel's `/ajax/telegram-place-order.php`.
- Order list through `/ajax/telegram-get-orders.php`.
- Coupon redeem, referral amount/link display, support and updates info.
- Order status notification endpoint and health endpoint.

## Known integration blocker — account linking

The supplied panel code describes a username → OTP → linked flow and exposes `/bridge/link-status` and `/bridge/unlink` calls. The website's visible PHP endpoints do **not** expose a verified bot-side OTP validation contract in the inspected files. This package deliberately does **not** link an account based only on a username or accept a guessed OTP. Until the exact OTP verification endpoint/contract is implemented and tested, account linking remains disabled and order/coupon/account features require a linked user. Do not remove this safety check.

## Known limitations to resolve before production

- Confirm the exact category/service JSON keys emitted by `telegram_bridge_sync_catalog()` against the live panel response; adapt the mapping if the keys differ.
- `orders_mirror` is used for order status notifications, but new orders are currently read from the panel bridge directly. Notification delivery can be enabled fully after confirming the panel's order ID format.
- Referral reward credit endpoint is present in the panel, but automatic referral credit should only be enabled after secure account-link verification is implemented.
- Add Funds is informational only in this build; actual deposit/payment verification should remain on the website until a dedicated safe API is provided.
- Test with a non-production/test account before live customer use.

## Panel endpoints used

- `POST /ajax/telegram-place-order.php`
- `POST /ajax/telegram-get-orders.php`
- `POST /ajax/telegram-verify-coupon.php`
- `GET /ajax/telegram-referral-amount.php`
- `GET /ajax/telegram-support-info.php`
- `GET /ajax/telegram-updates-info.php`

All protected calls send `X-Bridge-Secret`.

## Render environment

`TELEGRAM_BOT_TOKEN` = token from BotFather  
`PANEL_BASE_URL` = panel origin, no trailing slash  
`BRIDGE_SHARED_SECRET` = same newly rotated secret as panel config  
`DATABASE_URL` = Render Postgres internal URL  
`PGSSL` = `false` for Render internal DB URL; set `true` only if required

The package is deliberately cautious about account linking and does not claim to be fully production-verified.
