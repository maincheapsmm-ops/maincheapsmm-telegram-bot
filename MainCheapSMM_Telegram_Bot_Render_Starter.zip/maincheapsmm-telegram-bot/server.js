require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const { Telegraf, Markup } = require('telegraf');
const { pool, initDb } = require('./db');
const panel = require('./panel');

const token = process.env.TELEGRAM_BOT_TOKEN;
const secret = process.env.BRIDGE_SHARED_SECRET;
if (!token) throw new Error('Missing TELEGRAM_BOT_TOKEN');
if (!secret) throw new Error('Missing BRIDGE_SHARED_SECRET');

const app = express();
app.use(express.json({ limit: '256kb' }));
const bot = new Telegraf(token);
const sessions = new Map();

function auth(req, res, next) {
  const got = req.get('X-Bridge-Secret') || '';
  const a = Buffer.from(got);
  const b = Buffer.from(secret);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(403).json({ success: false, message: 'Forbidden' });
  }
  next();
}
function esc(s) { return String(s ?? '').replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }
async function getLinked(chatId) {
  const r = await pool.query('SELECT * FROM users_mirror WHERE telegram_chat_id=$1', [String(chatId)]);
  return r.rows[0] || null;
}
async function requireLinked(ctx) {
  const user = await getLinked(ctx.chat.id);
  if (!user) {
    await ctx.reply('Please link your website account first. Tap /start and follow the instructions.');
    return null;
  }
  return user;
}
function mainKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('🛍 Services', 'services'), Markup.button.callback('👤 My Account', 'account')],
    [Markup.button.callback('🧾 My Orders', 'orders'), Markup.button.callback('➕ Place Order', 'neworder')],
    [Markup.button.callback('🏷 Redeem Coupon', 'coupon'), Markup.button.callback('🎁 Refer & Earn', 'refer')],
    [Markup.button.callback('🙋 Support', 'support'), Markup.button.callback('📢 Updates', 'updates')]
  ]);
}
bot.start(async ctx => {
  const parts = (ctx.message.text || '').split(/\s+/);
  const referral = parts[1] && /^ref_\d+$/.test(parts[1]) ? Number(parts[1].slice(4)) : null;
  sessions.set(ctx.chat.id, { step: 'username', referrer_user_id: referral });
  const linked = await getLinked(ctx.chat.id);
  if (linked) {
    return ctx.reply(`Welcome back, ${esc(linked.username)}.`, { parse_mode: 'HTML', ...mainKeyboard() });
  }
  return ctx.reply('Welcome! To connect your website account, send your exact website username.\\n\\nNever send your website password or any payment PIN.');
});
bot.command('menu', async ctx => {
  const user = await getLinked(ctx.chat.id);
  if (!user) return ctx.reply('Please link your website account first with /start.');
  return ctx.reply('Main menu', mainKeyboard());
});
bot.command('cancel', async ctx => { sessions.delete(ctx.chat.id); await ctx.reply('Cancelled. Use /start to begin again.'); });

bot.on('text', async ctx => {
  const text = (ctx.message.text || '').trim();
  const state = sessions.get(ctx.chat.id);
  if (!state) return ctx.reply('Use /start to begin or /menu to open the menu.');
  try {
    if (state.step === 'username') {
      if (!/^[A-Za-z0-9_.-]{2,64}$/.test(text)) return ctx.reply('Please send a valid website username (2–64 letters/numbers/._-).');
      const r = await pool.query('SELECT user_id, username FROM users_mirror WHERE LOWER(username)=LOWER($1)', [text]);
      if (!r.rowCount) return ctx.reply('I could not find that username in the website sync yet. Please log in to your website and try again in a moment, or contact support.');
      state.user_id = r.rows[0].user_id;
      state.username = r.rows[0].username;
      state.step = 'otp';
      await ctx.reply('Now enter the one-time code shown in your logged-in website account’s Telegram linking notice. The code expires; never share it with anyone else.');
      return;
    }
    if (state.step === 'otp') {
      // OTP validation is intentionally not guessed here: this PHP ZIP does not expose a verified OTP-validation endpoint.
      // The bridge must implement POST /bridge/verify-link before account linking can safely be enabled.
      return ctx.reply('Account-link verification is not enabled yet because the matching secure OTP endpoint must be confirmed in the website bridge. No account has been linked. Please do not send passwords.');
    }
    if (state.step === 'order_link') {
      state.link = text; state.step = 'order_qty';
      return ctx.reply('Send the quantity (numbers only).');
    }
    if (state.step === 'order_qty') {
      const qty = Number(text);
      if (!Number.isSafeInteger(qty) || qty <= 0) return ctx.reply('Enter a positive whole-number quantity.');
      state.quantity = qty; state.step = 'order_confirm';
      return ctx.reply(`Confirm order?\\nService ID: ${state.service_id}\\nLink: ${state.link}\\nQuantity: ${qty}`, Markup.inlineKeyboard([[Markup.button.callback('✅ Confirm order', 'confirmorder'), Markup.button.callback('❌ Cancel', 'cancelorder')]]));
    }
    if (state.step === 'coupon') {
      const user = await requireLinked(ctx); if (!user) return;
      const result = await panel.verifyCoupon({ user_id: Number(user.user_id), coupon_code: text });
      sessions.delete(ctx.chat.id);
      return ctx.reply(result.message || (result.success ? 'Coupon redeemed.' : 'Could not redeem coupon.'));
    }
  } catch (e) {
    console.error('text handler:', e.message);
    return ctx.reply('Something went wrong. Please try again later.');
  }
});

bot.action('account', async ctx => {
  await ctx.answerCbQuery();
  const u = await requireLinked(ctx); if (!u) return;
  await ctx.reply(`Website username: ${u.username}\\nWebsite user ID: ${u.user_id}\\nBalance mirror: ${Number(u.balance || 0).toFixed(2)}\\n\\nBalance is read-only here; the website remains authoritative.`);
});
bot.action('services', async ctx => {
  await ctx.answerCbQuery();
  const u = await requireLinked(ctx); if (!u) return;
  const cats = await pool.query('SELECT category_id,name FROM categories_mirror ORDER BY sort_order,name LIMIT 30');
  if (!cats.rowCount) return ctx.reply('Service catalog has not synced yet. Run the website catalog sync after configuring the bridge.');
  const buttons = cats.rows.map(c => [Markup.button.callback(String(c.name).slice(0,55), `cat:${c.category_id}`)]);
  await ctx.reply('Choose a category:', Markup.inlineKeyboard(buttons));
});
bot.action(/^cat:(\d+)$/, async ctx => {
  await ctx.answerCbQuery();
  const catId = Number(ctx.match[1]);
  const r = await pool.query('SELECT service_id,name,price,min_qty,max_qty FROM services_mirror WHERE category_id=$1 ORDER BY sort_order,name LIMIT 40', [catId]);
  if (!r.rowCount) return ctx.reply('No services synced in this category.');
  for (const s of r.rows) {
    await ctx.reply(`${s.name}\\nService ID: ${s.service_id}\\nPrice: ${s.price} per 1K\\nMin: ${s.min_qty} | Max: ${s.max_qty}`,
      Markup.inlineKeyboard([[Markup.button.callback('Order this service', `choose:${s.service_id}`)]]));
  }
});
bot.action(/^choose:(\d+)$/, async ctx => {
  await ctx.answerCbQuery();
  const u = await requireLinked(ctx); if (!u) return;
  const id = Number(ctx.match[1]);
  const r = await pool.query('SELECT * FROM services_mirror WHERE service_id=$1', [id]);
  if (!r.rowCount) return ctx.reply('Service not found. Please refresh the catalog.');
  sessions.set(ctx.chat.id, { step: 'order_link', user_id: Number(u.user_id), service_id: id, service: r.rows[0] });
  await ctx.reply(`Selected: ${r.rows[0].name}\\nSend the target link/URL.`);
});
bot.action('neworder', async ctx => { await ctx.answerCbQuery(); await ctx.reply('To place an order, open Services and choose a service.'); });
bot.action('confirmorder', async ctx => {
  await ctx.answerCbQuery();
  const st = sessions.get(ctx.chat.id);
  if (!st || st.step !== 'order_confirm') return ctx.reply('Order session expired. Start again from Services.');
  const u = await getLinked(ctx.chat.id); if (!u) return ctx.reply('Please link your website account first.');
  try {
    const key = crypto.randomUUID();
    const result = await panel.placeOrder({ user_id: Number(u.user_id), service_id: Number(st.service_id), link: st.link, quantity: Number(st.quantity), idempotency_key: key });
    sessions.delete(ctx.chat.id);
    if (!result.success) return ctx.reply(result.message || 'Order could not be placed.');
    await ctx.reply(`✅ Order placed\\nOrder ID: ${result.order_id}\\nCharge: ${result.charge}\\nNew balance: ${result.new_balance}`, mainKeyboard());
  } catch (e) {
    console.error('place order:', e.message);
    await ctx.reply('Order result could not be confirmed. Please check My Orders before retrying to avoid duplicate orders.');
  }
});
bot.action('cancelorder', async ctx => { await ctx.answerCbQuery(); sessions.delete(ctx.chat.id); await ctx.reply('Order cancelled. No order was submitted.'); });
bot.action('orders', async ctx => {
  await ctx.answerCbQuery();
  const u = await requireLinked(ctx); if (!u) return;
  try {
    const result = await panel.getOrders({ action: 'list', user_id: Number(u.user_id), offset: 0, limit: 10 });
    if (!result.success || !result.orders?.length) return ctx.reply('No orders found.');
    for (const o of result.orders) await ctx.reply(`Order ${o.order_id}\\nStatus: ${o.order_status}\\nQuantity: ${o.quantity}\\nLink: ${o.link}\\nCreated: ${o.created_at}`);
  } catch (e) { console.error(e.message); await ctx.reply('Could not load orders right now.'); }
});
bot.action('coupon', async ctx => { await ctx.answerCbQuery(); const u = await requireLinked(ctx); if (!u) return; sessions.set(ctx.chat.id, { step: 'coupon' }); await ctx.reply('Send your coupon code.'); });
bot.action('refer', async ctx => {
  await ctx.answerCbQuery();
  const u = await requireLinked(ctx); if (!u) return;
  const amount = await panel.getReferralAmount().catch(() => ({ amount: null }));
  const botInfo = await bot.telegram.getMe();
  const link = `https://t.me/${botInfo.username}?start=ref_${u.user_id}`;
  await ctx.reply(`🎁 Refer & Earn\\nReward shown by website: ${amount.amount ?? 'configured by admin'}\\nShare your link:\\n${link}`);
});
bot.action('support', async ctx => {
  await ctx.answerCbQuery();
  const info = await panel.getSupportInfo().catch(() => ({}));
  const rows = [];
  if (info.telegram) rows.push([Markup.button.url('Telegram Support', `https://t.me/${String(info.telegram).replace(/^@/,'')}`)]);
  if (info.instagram) rows.push([Markup.button.url('Instagram Support', `https://instagram.com/${String(info.instagram).replace(/^@/,'')}`)]);
  await ctx.reply('🙋 Support', rows.length ? Markup.inlineKeyboard(rows) : undefined);
});
bot.action('updates', async ctx => {
  await ctx.answerCbQuery();
  const info = await panel.getUpdatesInfo().catch(() => ({ updates: [] }));
  const rows = (info.updates || []).filter(x => /^https?:\/\//i.test(x.link)).map(x => [Markup.button.url(String(x.name).slice(0,60), x.link)]);
  await ctx.reply('📢 Updates', rows.length ? Markup.inlineKeyboard(rows) : undefined);
});

app.get('/health', (_req, res) => res.json({ ok: true, service: 'maincheapsmm-telegram-bot' }));
app.use('/bridge', auth);
app.post('/bridge/sync-user', async (req, res) => {
  const { user_id, username } = req.body || {};
  if (!Number(user_id) || !String(username || '').trim()) return res.status(400).json({ success:false, message:'Invalid user' });
  await pool.query(`INSERT INTO users_mirror(user_id,username,updated_at) VALUES($1,$2,NOW())
    ON CONFLICT(user_id) DO UPDATE SET username=EXCLUDED.username,updated_at=NOW()`, [String(user_id), String(username)]);
  res.json({ success:true });
});
app.post('/bridge/sync-balance', async (req, res) => {
  const { user_id, balance } = req.body || {};
  if (!Number(user_id) || !Number.isFinite(Number(balance))) return res.status(400).json({ success:false, message:'Invalid balance' });
  await pool.query('UPDATE users_mirror SET balance=$2,updated_at=NOW() WHERE user_id=$1', [String(user_id), Number(balance)]);
  res.json({ success:true });
});
app.post('/bridge/sync-catalog', async (req, res) => {
  const { categories = [], services = [] } = req.body || {};
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM services_mirror');
    await client.query('DELETE FROM categories_mirror');
    for (const c of categories) {
      await client.query('INSERT INTO categories_mirror(category_id,name,sort_order) VALUES($1,$2,$3) ON CONFLICT(category_id) DO UPDATE SET name=EXCLUDED.name,sort_order=EXCLUDED.sort_order',
        [c.id ?? c.category_id, c.name, c.sort_order || 0]);
    }
    for (const s of services) {
      await client.query('INSERT INTO services_mirror(service_id,category_id,name,price,min_qty,max_qty,delivery,sort_order) VALUES($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT(service_id) DO UPDATE SET category_id=EXCLUDED.category_id,name=EXCLUDED.name,price=EXCLUDED.price,min_qty=EXCLUDED.min_qty,max_qty=EXCLUDED.max_qty,delivery=EXCLUDED.delivery,sort_order=EXCLUDED.sort_order',
        [s.id ?? s.service_id, s.category_id, s.name, s.rate ?? s.price ?? 0, s.min_qty || 1, s.max_qty || 1, s.delivery || '', s.sort_order || 0]);
    }
    await client.query('COMMIT');
    res.json({ success:true, categories:categories.length, services:services.length });
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
});
app.post('/bridge/order-status-update', async (req, res) => {
  const { order_id, status, start_count } = req.body || {};
  if (!order_id) return res.status(400).json({ success:false });
  await pool.query('UPDATE orders_mirror SET status=$2,start_count=$3 WHERE order_id=$1', [String(order_id), String(status || 'Pending'), start_count ?? null]);
  res.json({ success:true });
});
app.post('/bridge/order-status-notify', async (req, res) => {
  const { user_id, status, order_id, quantity, link } = req.body || {};
  const u = await pool.query('SELECT telegram_chat_id FROM users_mirror WHERE user_id=$1', [String(user_id)]);
  if (u.rows[0]?.telegram_chat_id) {
    await bot.telegram.sendMessage(String(u.rows[0].telegram_chat_id), `Order update\\nOrder: ${order_id}\\nStatus: ${status}\\nQuantity: ${quantity}\\nLink: ${link || ''}`).catch(()=>{});
  }
  res.json({ success:true });
});
app.get('/bridge/link-status', async (req, res) => {
  const userId = String(req.query.user_id || '');
  const r = await pool.query('SELECT telegram_chat_id FROM users_mirror WHERE user_id=$1', [userId]);
  res.json({ ok:true, linked: !!r.rows[0]?.telegram_chat_id, pending_otp:null });
});
app.post('/bridge/unlink', async (req, res) => {
  const { user_id } = req.body || {};
  await pool.query('UPDATE users_mirror SET telegram_chat_id=NULL,telegram_username=NULL,linked_at=NULL WHERE user_id=$1', [String(user_id)]);
  res.json({ success:true });
});

async function main() {
  await initDb();
  app.listen(Number(process.env.PORT || 10000), '0.0.0.0', () => console.log('Bridge server listening'));
  await bot.launch();
  console.log('Telegram bot polling started');
}
main().catch(err => { console.error(err); process.exit(1); });
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
