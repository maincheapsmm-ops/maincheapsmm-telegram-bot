function panelClient() {
  const base = (process.env.PANEL_BASE_URL || '').replace(/\/+$/, '');
  const secret = process.env.BRIDGE_SHARED_SECRET || '';
  if (!base || !secret) throw new Error('PANEL_BASE_URL and BRIDGE_SHARED_SECRET must be configured');
  return { base, headers: { 'X-Bridge-Secret': secret, 'Content-Type': 'application/json' } };
}

async function post(path, data) {
  const { base, headers } = panelClient();
  const res = await fetch(`${base}${path}`, {
    method: 'POST', headers, body: JSON.stringify(data),
    signal: AbortSignal.timeout(12000)
  });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { throw new Error(`Panel returned non-JSON (${res.status})`); }
  if (!res.ok && json.success !== false) throw new Error(`Panel request failed (${res.status})`);
  return json;
}
async function get(path) {
  const { base, headers } = panelClient();
  const res = await fetch(`${base}${path}`, { headers, signal: AbortSignal.timeout(10000) });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { throw new Error(`Panel returned non-JSON (${res.status})`); }
  if (!res.ok) throw new Error(`Panel request failed (${res.status})`);
  return json;
}
module.exports = {
  placeOrder: (data) => post('/ajax/telegram-place-order.php', data),
  getOrders: (data) => post('/ajax/telegram-get-orders.php', data),
  verifyCoupon: (data) => post('/ajax/telegram-verify-coupon.php', data),
  referralCredit: (data) => post('/ajax/telegram-referral-credit.php', data),
  getReferralAmount: () => get('/ajax/telegram-referral-amount.php'),
  getSupportInfo: () => get('/ajax/telegram-support-info.php'),
  getUpdatesInfo: () => get('/ajax/telegram-updates-info.php')
};
